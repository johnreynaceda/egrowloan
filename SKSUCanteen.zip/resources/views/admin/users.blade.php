@section('title', 'Users')
<x-admin-layout>
    <div>
        <livewire:user-list />
    </div>
</x-admin-layout>
