@section('title', 'Loans')
<x-admin-layout>
    <div>
        <livewire:admin.loan-list />
    </div>
</x-admin-layout>
