@section('title', 'Members')
<x-admin-layout>
    <div>
        <livewire:member-list />
    </div>
</x-admin-layout>
