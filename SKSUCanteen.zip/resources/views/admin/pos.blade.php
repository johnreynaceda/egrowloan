@section('title', 'Point of Sale')
<x-admin-layout>
    <div>
        <livewire:admin.point-of-sale />
    </div>
</x-admin-layout>
