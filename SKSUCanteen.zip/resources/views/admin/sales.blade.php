@section('title', 'Sales')
<x-admin-layout>
    <div>
        <livewire:admin.sales />
    </div>
</x-admin-layout>
