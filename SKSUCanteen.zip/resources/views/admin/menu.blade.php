@section('title', 'Menu')
<x-admin-layout>
    <div>
        <livewire:admin.menu-list />
    </div>
</x-admin-layout>
