@section('title', 'My Loans')
<x-customer-layout>
    <div>
        <livewire:customer.my-loan />
    </div>
</x-customer-layout>
