@section('title', 'Order Now')
<x-customer-layout>
    <div>
        <livewire:customer.order-dashboard />
    </div>
</x-customer-layout>
