@section('title', 'My Transactions')
<x-customer-layout>
    <div>
        <livewire:customer.customer-transaction />
    </div>
</x-customer-layout>
